/*
    实现的功能：
    1、手柄按钮控制0-5号舵机，摇杆控制6-7号电机；
    2、上位机图形化控制舵机
    3、可脱机存储控制

    主频： 22118400L
    单片机型号：IAP15W4K61S4

    存储那里待优化：改成时间调用动作组

*/
#include "main.h" /* 包含各类驱动文件 */

// 初始化其他

void main(void)
{
    app_gpio_init(); /* 初始化gpio相关引脚 */
    app_uart_init(); /*  初始化相关串口 */

    app_ps2_init();    /* 初始化PS2手柄 */

    SysTick_Init();   /* 初始化系统嘀答定时器，1ms定时一次 */

    app_setup_start(); /* 应用程序开始 */

    uart1_send_str("stc code start\r\n");
    while (1)
    {
        app_led_run();  /* 循环执行工作指示灯 */
        app_uart_run(); /* 串口应用循环运行 */
        app_ps2_run();  /* 循环处理PS2手柄上数据 */
    }
}


/* 单片机软件复位 */
void soft_reset(void)
{
    IAP_CONTR = 0X60;
}