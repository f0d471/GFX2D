#ifndef _MAIN_H_
#define _MAIN_H_
#include <stdio.h>  //标准库文件
#include <string.h> //标准库文件
#include <math.h>   //标准库文件

#include "stc15.h"

/* 驱动 */
#include "delay/y_delay.h" /* 包含延时函数 */
#include "timer/y_timer.h" /* 包含定时相关函数 */
#include "led/y_led.h"     /* 包含led相关函数 */
#include "beep/y_beep.h"   /* 包含蜂鸣器beep相关函数 */
#include "uart/y_uart.h" /* 串口相关函数 */
#include "ps2/y_ps2.h"     /* 包含手柄ps2相关文件 */

/* 应用 */
#include "app_gpio.h" /* gpio 任务相关函数 */
#include "app_uart.h" /* 串口任务相关函数 */
#include "app_ps2.h"  /* PS2手柄任务相关 */


#define FOSC 22118400L

typedef u8 bool;

void soft_reset(void); /* 单片机软件复位 */
#endif
