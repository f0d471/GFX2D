/*
 * @文件描述:
 * @作者: Q
 * @Date: 2023-02-13 16:09:51
 * @LastEditTime: 2023-04-08 15:25:04
 */
#ifndef _APP_GPIO_H_
#define _APP_GPIO_H_
#include "main.h"

void app_gpio_init(void);
void app_led_run(void);

void app_setup_start(void);
#endif
