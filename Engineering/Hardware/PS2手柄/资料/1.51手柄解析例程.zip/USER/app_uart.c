/*
 * @文件描述:
 * @作者: Q
 * @Date: 2023-02-13 14:01:12
 * @LastEditTime: 2023-04-13 09:22:37
 */
#include "app_uart.h"

/**
 * @函数描述: uart串口相关设备控制初始化
 * @return {*}
 */
void app_uart_init(void)
{
    uart1_init(115200); /* uart1串口初始化 */
    uart1_open();

    uart1_send_str("uart ok\r\n");
}

/**
 * @函数描述: 循环检测串口接收到的指令
 * @return {*}
 */
void app_uart_run(void)
{

    if (uart1_get_ok == 0)
        return;

    uart1_get_ok = 0;
}
