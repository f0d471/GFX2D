/*
 * @文件描述:
 * @作者: Q
 * @Date: 2023-02-13 14:01:12
 * @LastEditTime: 2023-04-14 09:38:44
 */
#include "app_ps2.h"


/**
 * @函数描述: PS2设备控制初始化
 * @return {*}
 */
void app_ps2_init(void)
{
    ps2_init(); /* PS2引脚初始化 */
}

/**
 * @函数描述: 循环执行工作指示灯任务运行，让LED闪烁 1s跳动一次
 * @return {*}
 */
void app_ps2_run(void)
{
    static u32 systick_ms_bak = 0;

    // 每500ms处理1次
    if (millis() - systick_ms_bak < 500)
    {
        return;
    }
    systick_ms_bak = millis();

    ps2_write_read(); /* 读取ps2数据 */
    printf("\r\n 0=%bu   1=%bu   2=%bu   3=%bu   4=%bu   5=%bu  6=%bu  7=%bu  8=%bu", (u8)psx_buf[0], psx_buf[1], psx_buf[2], psx_buf[3], psx_buf[4], psx_buf[5], psx_buf[6], psx_buf[7], psx_buf[8]);
    printf("    ****");
}
