/*
 * @文件描述:
 * @作者: Q
 * @Date: 2023-02-13 14:01:12
 * @LastEditTime: 2023-04-13 15:55:55
 */
#include "app_gpio.h"

/**
 * @函数描述: gpio相关设备控制初始化
 * @return {*}
 */
void app_gpio_init(void)
{
    led_init();  /* led gpio初始化 */
    beep_init(); /* 蜂鸣器beep gpio初始化 */

    LED_OFF();
    BEEP_OFF();
}

/**
 * @函数描述: 循环执行工作指示灯任务运行，让LED闪烁 1s跳动一次
 * @return {*}
 */
void app_led_run(void)
{
    static u32 time_count = 0;
    if (millis() - time_count < 1000)
        return;
    time_count = millis();
    LED_TOGGLE();
}

/* 系统启动信号 */
void app_setup_start(void)
{
    uint8_t i = 0;
    for (i = 0; i < 3; i++) /* 蜂鸣器LED 名叫闪烁 示意系统启动 */
    {
        BEEP_ON();
        LED_ON();
        delay_ms(100);
        BEEP_OFF();
        LED_OFF();
        delay_ms(100);
    }
}
