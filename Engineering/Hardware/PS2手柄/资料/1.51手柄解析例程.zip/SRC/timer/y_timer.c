/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放定时器相关的函数
 *	@函数列表:
 *	1.	void systick_init(void) -- 初始化systick
 *	2.	void SysTick_Handler(void) interrupt 19 -- systick中断函数
 *	3.	u32 millis(void) -- 滴答时钟查询
 *	4.	void TIM2_init(void) -- 初始化TIM2
 *	5.	void TIM2_IRQHandler(void) -- 输出舵机控制波形
 ****************************************************************************/
#include "timer/y_timer.h"

//#define FOSC 22118400L
static u32 systick_ms = 0;

void SysTick_Init(void)
{
	timer3_init();
}

u32 millis(void)
{
	return systick_ms;
}

void timer3_init(void) // 1毫秒@22.1184MHz
{
	T4T3M |= 0x02; // 定时器时钟1T模式
	T3L = 0x9A;	   // 设置定时初值
	T3H = 0xA9;	   // 设置定时初值
	T4T3M |= 0x08; // 定时器3开始计时
	IE2 |= 0X20;   // 打开外部中断
	EA = 1;		   // 总开关
}

void T3_IRQ(void) interrupt 19
{
	systick_ms++;
}


