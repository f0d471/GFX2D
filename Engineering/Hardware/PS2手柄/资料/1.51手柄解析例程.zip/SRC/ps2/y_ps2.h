/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月9日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放led相关的函数
 ****************************************************************************/

#ifndef _Y_PS2_H_
#define _Y_PS2_H_
#include "main.h"

extern u8 psx_buf[9];
extern u8 ps2_isConnected;

/* 定义PS2引脚，修改编号就可以修改PS2引脚 */
sbit  PS2_DAT=P0^4;	
sbit  PS2_CMD=P0^3;
sbit  PS2_ATT=P0^2;
sbit  PS2_CLK=P0^1;

/*******PS2相关指令表*******/
#define START_CMD 0x01   /* 开始命令 */
#define ASK_DAT_CMD 0x42 /* 请求数据 */

/*******PS2模式数据表*******/
#define PS2_MODE_GRN 0x41 /* 模拟绿灯 */
#define PS2_MODE_RED 0x73 /* 模拟红灯 */

/*******PS2相关函数声明*******/
void ps2_init(void);       /* PS2手柄初始化 */
void ps2_write_read(void); /* 读取手柄数据 */
#endif
