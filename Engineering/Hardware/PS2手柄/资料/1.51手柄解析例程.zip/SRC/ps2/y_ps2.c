/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月9日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放led相关的函数
 *	@函数列表:
 *	1.	void led_init(void) -- 初始化LED信号灯
 ****************************************************************************/

#include "ps2/y_ps2.h"

/* 数据存储数组 */
u8 psx_buf[9] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

/* PS2手柄初始化 */
void ps2_init(void)
{
    PS2_ATT = 1;
    PS2_CMD = 1;
    PS2_CLK = 1;
    // PS2_DAT = 0;
    // PS2_ACK = 1;
}

/***********************************************
    功能介绍：读写1个字节
    函数参数：无
    返回值：无
 ***********************************************/
u8 ps2_transfer(unsigned char dat)
{
    unsigned char rd_data, wt_data, i;
    wt_data = dat;
    rd_data = 0;
    for (i = 0; i < 8; i++)
    {
        PS2_CMD = (bit)(wt_data & (0x01 << i));
        PS2_CLK = 1;
        PS2_CLK = 0;
        delay_ns(3);
        PS2_CLK = 1;
        if (PS2_DAT)
        {
            rd_data |= 0x01 << i;
        }
        delay_ns(3);
    }
    return rd_data;
}

/***********************************************
    功能介绍：读取手柄数据
    函数参数：无
    返回值：无
 ***********************************************/
void ps2_write_read(void)
{
    PS2_ATT = 0;
    psx_buf[0] = ps2_transfer(START_CMD);
    psx_buf[1] = ps2_transfer(ASK_DAT_CMD);
    psx_buf[2] = ps2_transfer(psx_buf[0]);
    psx_buf[3] = ps2_transfer(psx_buf[0]);
    psx_buf[4] = ps2_transfer(psx_buf[0]);
    psx_buf[5] = ps2_transfer(psx_buf[0]);
    psx_buf[6] = ps2_transfer(psx_buf[0]);
    psx_buf[7] = ps2_transfer(psx_buf[0]);
    psx_buf[8] = ps2_transfer(psx_buf[0]);
    PS2_ATT = 1;
}
