/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放蜂鸣器相关的函数
 ****************************************************************************/

#ifndef _Y_BEEP_H_
#define _Y_BEEP_H_
#include "main.h"

/* 定义BEEP引脚，修改编号就可以修改BEEP引脚 */
sbit beep_pin = P2^6;

/* 控制BEEP的宏 */
#define BEEP_GET_LEVEL() beep_pin                      // 读取BEEP蜂鸣器状态
#define BEEP_OFF() {beep_pin = 0;}                                      // BEEP蜂鸣器关闭
#define BEEP_ON() {beep_pin = 1;}                                         // BEEP蜂鸣器打开
#define BEEP_TOGGLE() {beep_pin = ~beep_pin;} // 翻转BEEP蜂鸣器

#define beep_on() BEEP_ON()
#define beep_off() BEEP_OFF()

/*******BEEP相关函数声明*******/
void beep_init(void); // 初始化BEEP蜂鸣器
void beep_on_times(int times, int delay);
#endif
