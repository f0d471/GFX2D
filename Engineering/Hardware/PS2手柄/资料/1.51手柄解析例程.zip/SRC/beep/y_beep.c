/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放蜂鸣器相关的函数
 *	@函数列表:
 *	1.	void beep_init(void) -- 初始化蜂鸣器BEEP
 ****************************************************************************/

#include "beep/y_beep.h"

/* 初始化蜂鸣器BEEP */
void beep_init(void)
{
    P2M1 &= ~0x40; /* 0x40= 0100 0000 */
    P2M0 |= 0x40;
}

/**
 * @函数描述: 蜂鸣器鸣叫时间，单位ms
 * @param {uint16_t} times
 * @return {*}
 */
void beep_on_times(int times, int delay)
{
    uint8_t i;
    for (i = 0; i < times; i++)
    {
        BEEP_ON();
        delay_ms(delay);
        BEEP_OFF();
        delay_ms(delay);
    }
}
