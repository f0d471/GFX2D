#include "delay/y_delay.h"

void delay_ns(u16 t)
{
	while (t--)
		;
}

void delay_us(u16 t)
{
	while (t--)
	{
		_nop_();
	}
}

void delay_ms(u16 t) //@22.1184MHz
{
	for (; t > 0; t--)
	{
		unsigned char i, j;

		_nop_();
		i = 4;
		j = 146;
		do
		{
			while (--j)
				;
		} while (--i);
	}
}