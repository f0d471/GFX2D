/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放led相关的函数
 ****************************************************************************/

#ifndef _Y_LED_H_
#define _Y_LED_H_
#include "main.h"

/* 定义led引脚，修改编号就可以修改led引脚 */
#define LED_PIN P53

/* 控制LED的宏 */
#define LED_GET_LEVEL() LED_PIN                                // 读取LED信号灯状态
#define LED_ON() {LED_PIN = 0;}                                  // LED信号灯点亮
#define LED_OFF() {LED_PIN = 1;}                                   // LED信号灯熄灭
#define LED_TOGGLE() {LED_PIN = ~LED_PIN;} // 翻转LED信号灯

/*******LED相关函数声明*******/
void led_init(void); // 初始化LED信号灯
#endif
