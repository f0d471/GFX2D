/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放usart串口相关的函数
 ****************************************************************************/

#ifndef _Y_UART_H_
#define _Y_UART_H_
#include "main.h"

#define UART_BUF_SIZE 512 // 定义最大接收字节数

extern u8 uart_receive_buf[UART_BUF_SIZE]; // 接收缓冲,最大UART_BUF_SIZE个字节.末字节为换行符
extern uint16_t uart1_get_ok; // 接收完成标记

void uart1_init(u32 baud);
void uart1_send_byte(u8 dat);
void uart1_send_str(char *s);
void uart1_close(void);
void uart1_open(void);

#endif
