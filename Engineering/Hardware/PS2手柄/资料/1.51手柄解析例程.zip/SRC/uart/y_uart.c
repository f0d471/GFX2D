/****************************************************************************
 *	@笔者	：	Q
 *	@日期	：	2023年2月8日
 *	@所属	：	杭州友辉科技
 *	@功能	：	存放usart串口相关的函数
 *	@函数列表:
 *	1.	void uart1_init(u32 baud) -- 初始化串口1
 *	2.	void uart3_init(u32 baud) -- 初始化串口3
 *	3.	void uart1_send_byte(u8 dat) -- 串口1发送字节
 *	4.	void uart3_send_byte(u8 dat) -- 串口3发送字节
 *	5.	void uart1_send_str(char *s) -- 串口1发送字符串
 *	6.	void uart3_send_str(char *s) -- 串口3发送字符串
 ****************************************************************************/

#include "uart/y_uart.h"

u8 busy1 = 0;
u8 uart_receive_buf[UART_BUF_SIZE] = {0};
uint16_t uart1_get_ok = 0;

void uart1_init(u32 baud)
{

	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x01;		//串口1选择定时器2为波特率发生器
	AUXR |= 0x04;		//定时器2时钟为Fosc,即1T
	T2L = (65536 - (FOSC / 4 / baud));			//设定定时初值
	T2H = (65536 - (FOSC / 4 / baud))>>8;		//设定定时初值
	AUXR |= 0x10;		//启动定时器2
	
	EA = 1;
	ES = 1; //
}


void uart1_open(void)
{
	ES = 1;
}

void uart1_close(void)
{
	ES = 0;
}

/*----------------------------

----------------------------*/
void uart1_send_byte(u8 dat)
{
	SBUF = dat;
	while (busy1)
		; // 等待前面的数据发送完成
	busy1 = 1;
}

/********************/
/* 重定义 */
char putchar(char ch)
{
	SBUF = ch;
	while (busy1)
		; // 等待前面的数据发送完成
	busy1 = 1;
	return ch;
}

/*----------------------------

----------------------------*/
void uart1_send_str(char *s)
{
	while (*s)
	{						   //
		uart1_send_byte(*s++); //
	}
}


/*----------------------------

数据格式:

命令		$xxx!
单个舵机	#0P1000T1000!
多个舵机	{#0P1000T1000!#1P1000T1000!}
存储命令	<#0P1000T1000!#1P1000T1000!>

-----------------------------*/
void Uart1() interrupt 4 using 1
{
	static u16 buf_index = 0;
	static u8 sbuf_bak, cntf8 = 0;
	
	if (RI)
	{
		RI = 0; // 清除RI位
		sbuf_bak = SBUF;
		
		if (sbuf_bak == 0)
		{
			cntf8++;
			if (cntf8 >= 15)
			{
				IAP_CONTR = 0X60;
			}
		}
		else
		{
			cntf8 = 0;
		}
		
		if (uart1_get_ok)
			return;


		if (sbuf_bak == '$')
		{
			buf_index = 0;
		}

		uart_receive_buf[buf_index++] = sbuf_bak;

		if (sbuf_bak == '!')
		{
			uart_receive_buf[buf_index] = '\0';
			uart1_get_ok = 1;
		}

		if (buf_index >= UART_BUF_SIZE)
			buf_index = 0;
		
	}

	if (TI)
	{
		TI = 0;	   // 清除TI位
		busy1 = 0; // 清忙标志
	}
}

