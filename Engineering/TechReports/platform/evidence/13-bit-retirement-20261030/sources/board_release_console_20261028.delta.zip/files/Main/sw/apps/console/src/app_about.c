#include <stdint.h>
#include "board.h"
#include "core/format.h"
#include "assets.h"
#include "stg_slots.h"
#include "game/stg_text.h"
#include "renderer.h"
#include "appfw.h"
#include "console_platform.h"

static const stg_font s_font={STG_SLOT_FONT,ASSET_FONT8X16_CELL_W,ASSET_FONT8X16_CELL_H,
    ASSET_FONT8X16_COLS,0x20u,ASSET_FONT8X16_CELLS,0};
static const stg_font s_cyan={STG_SLOT_FONT_CYAN,ASSET_FONT_CYAN_CELL_W,ASSET_FONT_CYAN_CELL_H,
    ASSET_FONT_CYAN_COLS,0x20u,ASSET_FONT_CYAN_CELLS,ASSET_FONT_CYAN_KEY};
static uint32_t s_prev;
static int s_hw;
static int enter(appfw_ctx *c)
{
    if(stg_runtime_surfaces_stg(c->rt)!=0)return -1;
    s_hw=console_platform_hardware();s_prev=0;
    return renderer_prepare(s_hw,&c->rt->tab);
}
static int leave(appfw_ctx *c) { (void)c;return 0; }
static uint32_t line(gfx_list *list,int dst,uint32_t row,const char *name,uint32_t value)
{
    char text[32];core_out out;
    core_out_init(&out,text,sizeof text);core_out_u32(&out,value);
    return stg_text_draw(list,&s_cyan,dst,120,120+(int)row*32,name,NULL)+
           stg_text_draw(list,&s_font,dst,344,120+(int)row*32,text,NULL);
}
static int frame(appfw_ctx *c,uint32_t keys,uint32_t n)
{
    const uint32_t pressed=keys&~s_prev;
    const int dst=(int)(c->seq&1u);
    const gfx_rect all={0,0,FB_WIDTH-1,FB_HEIGHT-1};
    console_platform_stats p;
    gfx_list list;exec_sw_stats stats;
    uint32_t bad=0,cycles,ticket;
    (void)n;s_prev=keys;
    if(pressed&(BOARD_KEY_BOMB|BOARD_KEY_CONFIRM)) {
        appfw_request(appfw_app_id(APPFW_MENU));return APPFW_FRAME_IDLE;
    }
    console_platform_snapshot(&p);
    gfx_list_begin(&list,c->rt->cmds[c->seq&1u],c->rt->cap[c->seq&1u],&c->rt->tab);
    bad+=(uint32_t)(gfx_set_clip(&list,all)!=0);
    bad+=(uint32_t)(gfx_fill(&list,dst,all,0xff0a0e16u,GFX_EQ_COPY,0)!=0);
    bad+=stg_text_draw(&list,&s_cyan,dst,120,64,"SYSTEM INFORMATION",NULL);
    bad+=line(&list,dst,0,"UPTIME MS",p.tick_ms);
    bad+=line(&list,dst,1,"HEAP FREE",p.heap_free);
    bad+=line(&list,dst,2,"TASKS",p.tasks);
    bad+=line(&list,dst,3,"DISPLAY FIELDS",board_frame_count());
    bad+=line(&list,dst,4,"PRESENTS",board_swap_count());
    bad+=line(&list,dst,5,"IRQ FAULTS",board_irq_faults());
    bad+=stg_text_draw(&list,&s_font,dst,120,400,"ESC / SPACE: BACK TO MENU",NULL);
    bad+=stg_text_draw(&list,&s_font,dst,120,432,
                     console_platform_hardware()?"TI60 / FREERTOS / TICK 1 MS":"PC / HOST EVENT LOOP",NULL);
    if(bad || gfx_list_end(&list)!=0)return appfw_error("about build",-1);
    if(renderer_run(s_hw,&c->rt->tab,&c->rt->mem,&c->rt->es,&c->rt->err,&list,&stats,&cycles)!=0)
        return appfw_error("about render",-1);
    if(board_present_request(dst,&ticket)!=0 || board_present_wait(ticket)!=0)
        return appfw_error("about present",-1);
    c->shown=dst;++c->seq;return APPFW_FRAME_OK;
}
const appfw_app g_app_about={APPFW_ABOUT,"about","SYSTEM INFORMATION",enter,leave,frame};
