#include <stdint.h>
#include "board.h"
#include "renderer.h"
#include "game/sw6_cfg.h"
#include "game/sw6_scene_a.h"
#include "game/sw6_scene_b.h"
#include "game/sw6_hud.h"
#include "appfw.h"
#include "console_platform.h"

static sw6_scene_a s_a;
static sw6_scene_b s_b;
static uint32_t s_stage,s_start,s_prev;
static int s_hw;

static int enter(appfw_ctx *c)
{
    sw6_b_ctx ctx;
    uint32_t eq[4],bad=0;
    if(stg_runtime_surfaces_demo(c->rt)!=0)return -1;
    ctx=(sw6_b_ctx){&c->rt->tab,&c->rt->mem,&c->rt->es,&c->rt->err,c->rt->cmds[0],c->rt->cap[0]};
    sw6_b_begin(&s_b,SW6_K_DEFAULT);
    if(sw6_b_precompose(&s_b,&ctx,eq,&bad)!=0 || bad)return -1;
    sw6_a_begin(&s_a,SW6_SEED_DEMO,SW6_N_START);
    s_hw=console_platform_hardware() && c->rt->backend!=0;
    c->rt->backend=s_hw;
    if(renderer_prepare(s_hw,&c->rt->tab)!=0)return -1;
    s_stage=0;s_start=console_platform_ms();s_prev=0;
    return 0;
}
static int leave(appfw_ctx *c)
{
    int shown;
    if(renderer_pipeline_flush(&shown)!=0)return appfw_error("demo flush",-1);
    if(shown>=0)c->shown=shown;
    return 0;
}
static int frame(appfw_ctx *c,uint32_t keys,uint32_t n)
{
    const uint32_t pressed=keys&~s_prev;
    const uint32_t now=console_platform_ms();
    const int dst=(int)(c->seq&1u);
    gfx_list list;
    const gfx_rect all={0,0,FB_WIDTH-1,FB_HEIGHT-1};
    sw6_build_stat fs;
    sw6_hud_in hud={0};
    exec_sw_stats stats;
    uint32_t cycles,ticket,cmd,pix;
    (void)n;s_prev=keys;
    if(pressed&BOARD_KEY_SWAP) {
        if(console_platform_hardware())s_hw=!s_hw;
        else appfw_log("console capability cpu-only\r\n");
        c->rt->backend=s_hw;
        if(renderer_prepare(s_hw,&c->rt->tab)!=0)return -1;
    }
    if(now-s_start>=10000u || (pressed&BOARD_KEY_SCENE)) { s_stage^=1u;s_start=now; }
    sw6_build_stat_clear(&fs);
    gfx_list_begin(&list,c->rt->cmds[c->seq&1u],c->rt->cap[c->seq&1u],&c->rt->tab);
    if(gfx_set_clip(&list,all)!=0)return -1;
    if(!s_stage) {
        sw6_a_adjust(&s_a,(pressed&BOARD_KEY_UP)!=0,(pressed&BOARD_KEY_DOWN)!=0);
        sw6_a_update(&s_a);
        if(gfx_fill(&list,dst,all,SW6_BG_COLOR,GFX_EQ_COPY,0)!=0)return -1;
        sw6_a_build(&s_a,&list,dst,&fs);
    } else {
        uint32_t scene;
        sw6_b_adjust(&s_b,(pressed&BOARD_KEY_UP)!=0,(pressed&BOARD_KEY_DOWN)!=0);
        scene=sw6_b_step(&s_b);
        if(gfx_blit(&list,SW6_SLOT_OFF(scene),0,0,dst,0,0,FB_WIDTH,FB_HEIGHT,GFX_EQ_COPY,0,0,0)!=0)return -1;
    }
    hud.n=s_stage?0:s_a.n;hud.k=s_stage?s_b.k:0;
    hud.sw_fps=c->fps_milli/1000u;hud.sw_fps_valid=!s_hw && c->fps_milli!=0;
    hud.hw_fps=hud.sw_fps;hud.hw_fps_valid=s_hw && c->fps_milli!=0;hud.live=1;
    sw6_hud_build(&list,dst,&hud,&cmd,&pix);
    if(fs.bad || sw6_hud_bad() || gfx_list_end(&list)!=0 || list.rejected || list.overflow)
        return appfw_error("demo build",-1);
    if(renderer_run(s_hw,&c->rt->tab,&c->rt->mem,&c->rt->es,&c->rt->err,&list,&stats,&cycles)!=0)
        return appfw_error("demo render",-1);
    if(board_present_request(dst,&ticket)!=0 || board_present_wait(ticket)!=0)
        return appfw_error("demo present",-1);
    c->shown=dst;++c->seq;return APPFW_FRAME_OK;
}
const appfw_app g_app_demo={APPFW_DEMO,"demo","2D GRAPHICS DEMO",enter,leave,frame};
