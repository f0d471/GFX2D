/* Ti60 scheduler port. Product logic lives in appfw.c and is also used on PC. */
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "board.h"
#include "core/crc32.h"
#include "core/format.h"
#include "rtos_irq.h"
#include "appfw.h"
#include "console_platform.h"

static volatile uint32_t s_pending, s_held, s_idle, s_monitor;

uint32_t console_platform_ms(void) { return (uint32_t)xTaskGetTickCount(); }
int console_platform_hardware(void) { return 1; }
uint32_t console_platform_keys(void)
{
    uint32_t keys;
    taskENTER_CRITICAL();keys=s_pending;s_pending=s_held;taskEXIT_CRITICAL();
    return keys;
}
uint32_t console_platform_held(void) { return s_held; }
void console_platform_snapshot(console_platform_stats *p)
{
    p->tick_ms=console_platform_ms();p->heap_free=(uint32_t)xPortGetFreeHeapSize();
    p->tasks=(uint32_t)uxTaskGetNumberOfTasks();p->idle=s_idle;p->monitor=s_monitor;
}
void console_platform_idle(void) { vTaskDelay(1); }
static void cooperate(void)
{
    if(xTaskGetSchedulerState()==taskSCHEDULER_RUNNING)(void)rtos_wait_frame(1);
}
static void input_task(void *arg)
{
    (void)arg;
    for(;;) {
        uint32_t keys;
        taskENTER_CRITICAL();keys=board_keys();s_pending|=keys;s_held=keys;taskEXIT_CRITICAL();
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}
static void monitor_task(void *arg)
{
    (void)arg;
    for(;;) { vTaskDelay(pdMS_TO_TICKS(1000));++s_monitor; }
}
static void runner_task(void *arg)
{
    (void)arg;
    board_set_wait_hook(cooperate);
    if(appfw_init(APPFW_MENU)!=0) {
        board_puts("console fatal boot\r\n");
        for(;;)vTaskDelay(pdMS_TO_TICKS(1000));
    }
    for(;;) {
        (void)appfw_step(console_platform_keys());
        /* Even CPU reference rendering yields between frames. Short hardware
         * waits remain bounded; display waits also use the cooperation hook. */
        console_platform_idle();
    }
}
int main(void)
{
    board_init();board_product_keys(1);crc32_init();
    if(rtos_irq_init()!=0) { board_puts("console fatal irq\r\n");for(;;){} }
    if(xTaskCreate(input_task,"inputd",512,NULL,3,NULL)!=pdPASS ||
       xTaskCreate(runner_task,"runner",16384,NULL,2,NULL)!=pdPASS ||
       xTaskCreate(monitor_task,"monitor",1024,NULL,1,NULL)!=pdPASS) {
        board_puts("console fatal tasks\r\n");for(;;){}
    }
    rtos_trap_install();vTaskStartScheduler();
    for(;;){}
}
void vApplicationIdleHook(void) { ++s_idle; }
void vApplicationMallocFailedHook(void)
{
    taskDISABLE_INTERRUPTS();board_puts("console fatal malloc\r\n");for(;;){}
}
void vApplicationStackOverflowHook(TaskHandle_t task,char *name)
{
    (void)task;(void)name;
    taskDISABLE_INTERRUPTS();board_puts("console fatal stack\r\n");for(;;){}
}
void vAssertCalled(const char *file,int line)
{
    char text[160];core_out out;
    taskDISABLE_INTERRUPTS();core_out_init(&out,text,sizeof text);
    core_out_str(&out,"console fatal assert ");core_out_str(&out,file);
    core_out_ch(&out,' ');core_out_u32(&out,(uint32_t)line);
    core_out_str(&out,"\r\n");board_puts(text);for(;;){}
}
