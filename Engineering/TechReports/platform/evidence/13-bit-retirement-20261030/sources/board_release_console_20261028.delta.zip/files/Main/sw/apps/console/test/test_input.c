#include <stdio.h>
#include <string.h>
#include "board.h"
#include "key_packet.h"
static unsigned fail;
/* Independent polynomial long division, not the decoder's shift register. */
static uint8_t reference(uint32_t lo,uint32_t hi)
{
    uint32_t word=((lo<<7)|hi)<<7;
    int bit;
    for(bit=20;bit>=7;--bit)if(word&(1u<<(unsigned)bit))word^=0x89u<<(unsigned)(bit-7);
    return (uint8_t)(word&127u);
}
#define CHECK(c,n) do { if(!(c)) { ++fail;printf("FAIL %s\n",n); } } while(0)
int main(void)
{
    key_packet_decoder d={0};uint32_t k,got=0;
    for(k=0;k<1024u;++k) {
        uint32_t check=(k^(k>>4)^(k>>8))&15u;
        CHECK(!key_packet_feed(&d,(uint8_t)(0x80u|(k&127u)),&got),"legacy-header");
        CHECK(key_packet_feed(&d,(uint8_t)((check<<3)|(k>>7)),&got)&&got==k,"legacy-roundtrip");
    }
    for(k=0;k<16384u;++k) {
        const uint8_t lo=(uint8_t)(k&127u),hi=(uint8_t)(k>>7);
        const uint8_t check=reference(lo,hi);
        CHECK(!key_packet_feed(&d,255,&got),"extended-sync-a");
        CHECK(!key_packet_feed(&d,127,&got),"extended-sync-b");
        CHECK(!key_packet_feed(&d,lo,&got),"extended-lo");
        CHECK(!key_packet_feed(&d,hi,&got),"extended-hi");
        CHECK(key_packet_feed(&d,check,&got)&&got==k,"extended-roundtrip");
        (void)key_packet_feed(&d,255,&got);(void)key_packet_feed(&d,127,&got);
        (void)key_packet_feed(&d,lo,&got);(void)key_packet_feed(&d,hi,&got);
        CHECK(!key_packet_feed(&d,(uint8_t)(check^1u),&got),"bad-checksum-rejected");
        for(unsigned bit=0;bit<14u;++bit) {
            uint8_t badlo=lo,badhi=hi;
            if(bit<7u)badlo^=(uint8_t)(1u<<bit);else badhi^=(uint8_t)(1u<<(bit-7u));
            (void)key_packet_feed(&d,255,&got);(void)key_packet_feed(&d,127,&got);
            (void)key_packet_feed(&d,badlo,&got);(void)key_packet_feed(&d,badhi,&got);
            CHECK(!key_packet_feed(&d,check,&got),"single-payload-bit-error-rejected");
        }
    }
    memset(&d,0,sizeof d);(void)key_packet_feed(&d,255,&got);(void)key_packet_feed(&d,127,&got);
    (void)key_packet_feed(&d,12,&got);(void)key_packet_feed(&d,128,&got);
    CHECK(key_packet_feed(&d,0,&got)&&got==0,"truncated-frame-resyncs-to-release");
    board_product_keys(0);
    CHECK(board_map_physical_keys(15)==15,"legacy-four-keys-unchanged");
    board_product_keys(1);
    CHECK(board_map_physical_keys(BOARD_KEY_LEFT|BOARD_KEY_RIGHT)==BOARD_KEY_CONFIRM,"physical-confirm");
    CHECK(board_map_physical_keys(BOARD_KEY_UP|BOARD_KEY_DOWN)==BOARD_KEY_BACK,"physical-back");
    CHECK(board_map_physical_keys(BOARD_KEY_UP|BOARD_KEY_LEFT)==(BOARD_KEY_UP|BOARD_KEY_LEFT),"normal-direction-pair");
    printf("input exhaustive legacy=1024 extended=16384 fail %u\n",fail);
    return fail?1:0;
}
