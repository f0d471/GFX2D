/* Shared product application model: PC loop and RTOS runner drive the same API. */
#ifndef APPFW_H
#define APPFW_H
#include <stdint.h>
#include "core/logq.h"
#include "gfx/gfx.h"
#include "stg_runtime.h"

enum { APPFW_MENU=0, APPFW_DEMO=1, APPFW_GAME=2, APPFW_PRESS=3,
       APPFW_R4=4, APPFW_ABOUT=5 };
enum { APPFW_FRAME_OK=0, APPFW_FRAME_IDLE=1 };

typedef struct appfw_ctx {
    stg_runtime *rt;
    uint32_t seq;
    int shown;
    logq *log;
    uint32_t fps_milli;
} appfw_ctx;

typedef struct appfw_app {
    uint32_t id;             /* Stable command ID, independent of list order. */
    const char *name;
    const char *desc;
    int (*enter)(appfw_ctx *ctx);
    int (*leave)(appfw_ctx *ctx);
    /* 0=completed render, 1=transition/no render, negative=failure. */
    int (*frame)(appfw_ctx *ctx, uint32_t keys, uint32_t frame);
} appfw_app;

/* Only launchable content is enumerated. Menu is a separate system page. */
const appfw_app *const *appfw_apps(uint32_t *count);
const appfw_app *appfw_app_at(uint32_t index);
const appfw_app *appfw_find(const char *name);
const appfw_app *appfw_app_id(uint32_t id);
int appfw_available(const appfw_app *app);
void appfw_request(const appfw_app *app);
int appfw_init(uint32_t start_id);
int appfw_step(uint32_t keys);
int appfw_shutdown(void);
int appfw_in_shell(void);
uint32_t appfw_input_held(void);
uint32_t appfw_errors(void);
uint32_t appfw_active_id(void);
void appfw_log(const char *line);
int appfw_error(const char *detail, int code);
#endif
