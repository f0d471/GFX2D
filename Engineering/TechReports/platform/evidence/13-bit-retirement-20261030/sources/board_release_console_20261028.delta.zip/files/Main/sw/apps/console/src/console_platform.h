/* Scheduler port. The application manager never includes FreeRTOS or SDL. */
#ifndef CONSOLE_PLATFORM_H
#define CONSOLE_PLATFORM_H
#include <stdint.h>
typedef struct {
    uint32_t tick_ms, heap_free, tasks, idle, monitor;
} console_platform_stats;
uint32_t console_platform_ms(void);
uint32_t console_platform_keys(void);
uint32_t console_platform_held(void);
int console_platform_hardware(void);
void console_platform_snapshot(console_platform_stats *stats);
void console_platform_idle(void);
#endif
