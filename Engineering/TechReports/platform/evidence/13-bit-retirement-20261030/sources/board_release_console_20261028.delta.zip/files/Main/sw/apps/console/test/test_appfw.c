/* Actual appfw.c + registry with fake platform/resources: lifecycle fault tests. */
#include <stdio.h>
#include <string.h>
#include "board.h"
#include "appfw.h"
#include "console_platform.h"
#include "stg_modes.h"
#include "r4.h"
#include "renderer.h"

static unsigned failures;
static uint32_t now_ms,swaps,held;
static int hardware,caps,enter_fail,frame_fail,leave_fail,leave_left,recover_fail;
static unsigned entered[6],left[6],framed[6],recoveries;
static uint32_t delivered[6];
static char output[65536];static size_t output_len;
static int draw_frames=1;
#define CHECK(c,name) do { if(!(c)) { ++failures;printf("FAIL %s\n",name); } else printf("ok %s\n",name); } while(0)

static int enter_id(unsigned id) { ++entered[id];return enter_fail==(int)id?-1:0; }
static int leave_id(unsigned id)
{
    ++left[id];
    if(leave_fail==(int)id && leave_left) { --leave_left;return -1; }
    return 0;
}
static int frame_id(unsigned id,appfw_ctx *ctx,uint32_t keys)
{
    ++framed[id];delivered[id]=keys;
    if(frame_fail==(int)id)return -1;
    if(draw_frames) { ++swaps;ctx->shown=(int)(ctx->seq&1u);++ctx->seq; }
    return 0;
}
#define APP(symbol,id,text) \
static int symbol##_enter(appfw_ctx *c) { (void)c;return enter_id(id); } \
static int symbol##_leave(appfw_ctx *c) { (void)c;return leave_id(id); } \
static int symbol##_frame(appfw_ctx *c,uint32_t k,uint32_t f) { (void)f;return frame_id(id,c,k); } \
const appfw_app symbol={id,text,text,symbol##_enter,symbol##_leave,symbol##_frame}
APP(g_app_menu,0,"menu");APP(g_app_demo,1,"demo");APP(g_app_stg,2,"stg");
APP(g_app_press,3,"press");APP(g_app_r4,4,"r4");APP(g_app_about,5,"about");

uint32_t console_platform_ms(void) { return now_ms; }
uint32_t console_platform_keys(void) { return held; }
uint32_t console_platform_held(void) { return held; }
int console_platform_hardware(void) { return hardware; }
void console_platform_snapshot(console_platform_stats *p)
{ *p=(console_platform_stats){now_ms,57920,4,now_ms,now_ms/1000}; }
void console_platform_idle(void) {}
uint32_t board_swap_count(void) { return swaps; }
uint32_t board_irq_frame_events(void) { return now_ms*60u/1000u; }
uint32_t board_irq_faults(void) { return 0; }
uint32_t board_tx_room(void) { return 65535; }
void board_wait_frame(void) { ++now_ms; }
void board_wait_yield(void) {}
void board_puts(const char *s)
{
    size_t n=strlen(s);
    if(output_len+n<sizeof output) { memcpy(output+output_len,s,n+1);output_len+=n; }
}
void exec_sw_reset(exec_sw_state *s) { memset(s,0,sizeof *s); }
int stg_runtime_boot(stg_runtime *rt) { memset(rt,0,sizeof *rt);return 0; }
void stg_runtime_set_active(stg_runtime *rt) { (void)rt; }
int stg_runtime_has_raster(void) { return caps; }
int stg_runtime_tex_load(stg_runtime *rt) { rt->tex_ready=1;return 0; }
void stg_runtime_r4_install_hooks(void) {}
void stg_modes_set_log(logq *q) { (void)q; }
void stg_modes_reset(void) {}
void r4_set_log(logq *q) { (void)q; }
void r4_set_key_source(uint32_t (*fn)(void)) { (void)fn; }
int r4_backend_hardware(void) { return hardware; }
uint32_t r4_current_scene(void) { return 0; }
uint32_t r4_current_ladder(void) { return 2; }
int renderer_recover(void) { ++recoveries;return recover_fail?-1:0; }

static void reset(void)
{
    memset(entered,0,sizeof entered);memset(left,0,sizeof left);memset(framed,0,sizeof framed);
    memset(delivered,0,sizeof delivered);memset(output,0,sizeof output);output_len=0;
    now_ms=swaps=held=0;hardware=0;caps=1;
    enter_fail=frame_fail=leave_fail=-1;leave_left=recover_fail=0;recoveries=0;draw_frames=1;
    CHECK(appfw_init(0)==0,"init-menu");
}
static void step(uint32_t keys) { held=keys;(void)appfw_step(keys); }

int main(void)
{
    uint32_t count;
    reset();
    CHECK(appfw_active_id()==0,"default-is-system-menu");
    CHECK(appfw_apps(&count)[0]->id==1 && count==5,"menu-not-launchable-content");
    CHECK(appfw_app_id(1)==&g_app_demo && appfw_app_id(2)==&g_app_stg &&
          appfw_app_id(3)==&g_app_press && appfw_app_id(4)==&g_app_r4,"stable-four-ids");
    step(128);step(0);CHECK(appfw_active_id()==1,"global-demo");
    step(256);step(0);CHECK(appfw_active_id()==2,"global-game");
    step(512);step(0);CHECK(appfw_active_id()==3,"global-pressure");
    step(896);step(0);CHECK(appfw_active_id()==4,"global-r4");
    CHECK((delivered[4]&BOARD_KEY_LAUNCH_MASK)==0,"launch-not-delivered-to-app");
    step(BOARD_KEY_SCENE);CHECK(delivered[4]==BOARD_KEY_SCENE,"scene-is-private-action");
    step(0);step(BOARD_KEY_BACK);CHECK(appfw_active_id()==0,"back-independent-of-frame-rate");
    step(BOARD_KEY_BACK);CHECK(entered[0]==2,"held-back-does-not-reenter");

    reset();appfw_request(&g_app_stg);step(BOARD_KEY_BOMB);step(BOARD_KEY_BOMB);
    CHECK(delivered[2]==0,"confirm-event-consumed-until-release");
    step(0);step(BOARD_KEY_BOMB);CHECK(delivered[2]==BOARD_KEY_BOMB,"new-business-key-after-release");
    step(0);step(BOARD_KEY_MODE1|BOARD_KEY_UP);step(BOARD_KEY_UP);
    CHECK(delivered[1]==BOARD_KEY_UP,"held-movement-survives-navigation");

    reset();enter_fail=4;step(896);step(0);
    CHECK(appfw_active_id()==0 && appfw_errors()==1,"failed-enter-recovers-to-menu");
    CHECK(framed[4]==0 && left[4]==1,"failed-app-never-frames-and-cleans-up");

    reset();step(128);step(0);frame_fail=1;step(0);
    CHECK(appfw_active_id()==0 && recoveries==1,"frame-failure-recovers");
    { unsigned n=framed[1];step(0);CHECK(framed[1]==n,"failed-frame-not-called-again"); }

    reset();step(128);step(0);leave_fail=1;leave_left=1;step(256);
    CHECK(appfw_active_id()==0 && recoveries==1 && framed[2]==0,"leave-failure-cannot-activate-next");

    reset();step(128);step(0);frame_fail=1;recover_fail=1;step(0);
    CHECK(appfw_active_id()==UINT32_MAX,"undrained-engine-stays-faulted");
    { unsigned n=framed[0];step(BOARD_KEY_BACK);CHECK(framed[0]==n,"no-menu-draw-before-drain"); }
    recover_fail=0;frame_fail=-1;step(0);step(BOARD_KEY_BACK);
    CHECK(appfw_active_id()==0,"explicit-retry-after-recovery");

    reset();hardware=1;caps=0;step(896);step(0);
    CHECK(appfw_active_id()==0 && framed[4]==0 && appfw_errors()==0,"unsupported-app-is-denied");
    reset();appfw_request(&g_app_stg);appfw_request(NULL);step(0);
    CHECK(appfw_active_id()==0,"pending-launch-can-be-cancelled");
    reset();step(128);step(0);leave_fail=1;leave_left=1;
    CHECK(appfw_shutdown()!=0 && appfw_active_id()==UINT32_MAX,"failed-shutdown-is-not-successful-leave");

    reset();draw_frames=0;now_ms=1100;swaps=66;step(0);
    while(output_len<10 || strstr(output,"fps_milli")==NULL)step(0);
    CHECK(strstr(output,"fps_milli 60000")!=NULL,"fps-normalized-by-elapsed-time");
    CHECK(appfw_shutdown()==0,"clean-shutdown");
    printf("fail %u\n",failures);return failures?1:0;
}
