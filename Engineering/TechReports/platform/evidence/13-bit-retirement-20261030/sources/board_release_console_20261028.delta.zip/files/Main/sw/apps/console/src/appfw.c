#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "board.h"
#include "core/format.h"
#include "core/logq.h"
#include "stg_modes.h"
#include "r4.h"
#include "renderer.h"
#include "appfw.h"
#include "console_platform.h"

#define LOGQ_BYTES 8192u
#define LOG_TAKE_MAX 256u
static logq s_logq;
static char s_log_mem[LOGQ_BYTES], s_log_out[LOG_TAKE_MAX+1u];
static stg_runtime s_rt;
static appfw_ctx s_ctx;
static const appfw_app *s_active, *s_request, *s_cleanup;
static uint32_t s_frames, s_errors, s_prev, s_blocked;
static uint32_t s_stat_ms, s_stat_swaps, s_app_swaps;
static int s_fault;
extern const appfw_app g_app_menu;
extern const appfw_app *const g_appfw_registry[];
extern const uint32_t g_appfw_registry_n;

const appfw_app *const *appfw_apps(uint32_t *count)
{
    *count=g_appfw_registry_n;
    return g_appfw_registry;
}
const appfw_app *appfw_app_at(uint32_t index)
{
    return index<g_appfw_registry_n?g_appfw_registry[index]:NULL;
}
const appfw_app *appfw_app_id(uint32_t id)
{
    uint32_t i;
    if (id==APPFW_MENU) return &g_app_menu;
    for(i=0;i<g_appfw_registry_n;++i)
        if(g_appfw_registry[i]->id==id)return g_appfw_registry[i];
    return NULL;
}
const appfw_app *appfw_find(const char *name)
{
    uint32_t i;
    if(strcmp(name,g_app_menu.name)==0)return &g_app_menu;
    for(i=0;i<g_appfw_registry_n;++i)
        if(strcmp(name,g_appfw_registry[i]->name)==0)return g_appfw_registry[i];
    return NULL;
}
int appfw_available(const appfw_app *app)
{
    if(!app)return 0;
    return app->id!=APPFW_R4 || !console_platform_hardware() || stg_runtime_has_raster();
}
void appfw_request(const appfw_app *app)
{
    if(!app) { s_request=NULL;return; }
    if(app && appfw_app_id(app->id)==app && appfw_available(app))s_request=app;
}
int appfw_in_shell(void) { return s_active==&g_app_menu && !s_fault; }
uint32_t appfw_active_id(void) { return s_active?s_active->id:UINT32_MAX; }
uint32_t appfw_errors(void) { return s_errors; }
uint32_t appfw_input_held(void)
{
    return console_platform_held() & ~BOARD_KEY_LAUNCH_MASK & ~BOARD_KEY_BACK & ~s_blocked;
}
void appfw_log(const char *line) { (void)logq_put(&s_logq,line); }
static void pump(void)
{
    uint32_t n=board_tx_room();
    if(n>LOG_TAKE_MAX)n=LOG_TAKE_MAX;
    if(n && logq_used(&s_logq)) {
        (void)logq_take(&s_logq,s_log_out,n);
        board_puts(s_log_out);
    }
}
int appfw_error(const char *detail,int code)
{
    char line[128];core_out out;
    core_out_init(&out,line,sizeof line);
    core_out_str(&out,"console detail ");core_out_str(&out,detail);
    core_out_str(&out," code ");core_out_u32(&out,code<0?0u-(uint32_t)code:(uint32_t)code);
    core_out_str(&out,"\r\n");appfw_log(line);
    return -1;
}
static void event(const char *kind,const appfw_app *app)
{
    char line[96];core_out out;
    core_out_init(&out,line,sizeof line);core_out_str(&out,"console ");
    core_out_str(&out,kind);core_out_ch(&out,' ');core_out_str(&out,app->name);
    core_out_str(&out,"\r\n");appfw_log(line);
}
static void error_event(const char *stage)
{
    char line[96];core_out out;
    ++s_errors;
    core_out_init(&out,line,sizeof line);core_out_str(&out,"console error ");
    core_out_str(&out,stage);core_out_str(&out," total ");core_out_u32(&out,s_errors);
    core_out_str(&out,"\r\n");appfw_log(line);
}
static void complete(const appfw_app *app)
{
    char line[160];core_out out;
    core_out_init(&out,line,sizeof line);core_out_str(&out,"console complete app ");
    core_out_str(&out,app->name);core_out_str(&out," id ");core_out_u32(&out,app->id);
    core_out_str(&out," frames ");core_out_u32(&out,s_frames);
    core_out_str(&out," presents ");core_out_u32(&out,board_swap_count()-s_app_swaps);
    core_out_str(&out," errors ");core_out_u32(&out,s_errors);
    core_out_str(&out,"\r\n");appfw_log(line);
}
static void choose_back_buffer(void)
{
    if(s_ctx.shown>=0)s_ctx.seq=(s_ctx.seq&~1u)|((uint32_t)s_ctx.shown^1u);
}
static int activate(const appfw_app *next)
{
    if(!next || !appfw_available(next))return -1;
    exec_sw_reset(&s_rt.es);
    choose_back_buffer();
    if(next->enter(&s_ctx)!=0)return -1;
    s_active=next; /* Commit only after resource preparation succeeds. */
    s_frames=0;s_ctx.fps_milli=0;
    s_stat_ms=console_platform_ms();s_stat_swaps=board_swap_count();
    s_app_swaps=s_stat_swaps;
    event("enter",next);
    return 0;
}
static int recover(const char *stage)
{
    error_event(stage);
    s_active=NULL;s_request=NULL;s_fault=1;
    /* No new surface or framebuffer writes until the engine has recovered. */
    if(renderer_recover()!=0)return -1;
    if(s_cleanup && s_cleanup->leave(&s_ctx)!=0)return -1;
    s_cleanup=NULL;
    stg_modes_reset();s_rt.tex_on=0;
    s_rt.tex_ready=0;
    if(console_platform_hardware())(void)stg_runtime_tex_load(&s_rt);
    s_blocked|=s_prev;
    if(activate(&g_app_menu)!=0)return -1;
    s_fault=0;
    return 0;
}
static int switch_to(const appfw_app *next,uint32_t held)
{
    const appfw_app *old=s_active;
    s_request=NULL;
    if(next==old && !s_fault)return 0;
    if(!appfw_available(next)) { event("unavailable",next);return 0; }
    if(s_fault)return recover("retry");
    if(old && old->leave(&s_ctx)!=0) { s_cleanup=old;return recover("leave"); }
    if(old) { complete(old);event("leave",old); }
    s_active=NULL;
    if(activate(next)!=0) { s_cleanup=next;return recover("enter"); }
    s_blocked|=held&(BOARD_KEY_LAUNCH_MASK|BOARD_KEY_BACK|BOARD_KEY_CONFIRM|
                    BOARD_KEY_BOMB|BOARD_KEY_SCENE|BOARD_KEY_SWAP|BOARD_KEY_SLOW);
    /* Retain held movement; consume control actions until release. */
    return 0;
}
static const char *backend_name(void)
{
    static const char *const names[]={"sw","hw","hw-tex","hw-strip"};
    if(!s_active)return "none";
    if(s_active && (s_active->id==APPFW_MENU || s_active->id==APPFW_ABOUT))
        return console_platform_hardware()?"hw":"sw";
    if(s_active && s_active->id==APPFW_R4)return r4_backend_hardware()?"hw":"sw";
    return names[(unsigned)s_rt.backend<4u?(unsigned)s_rt.backend:0u];
}
static void status(void)
{
    const uint32_t now=console_platform_ms(), elapsed=now-s_stat_ms;
    console_platform_stats p;
    char line[320];core_out out;
    if(elapsed<1000u)return;
    s_ctx.fps_milli=(uint32_t)(((uint64_t)(board_swap_count()-s_stat_swaps)*1000000u)/elapsed);
    s_stat_ms=now;s_stat_swaps=board_swap_count();
    console_platform_snapshot(&p);
    core_out_init(&out,line,sizeof line);
    core_out_str(&out,"console status v 2 app ");core_out_str(&out,s_active?s_active->name:"fault");
#define VALUE(label,value) do { core_out_str(&out,label);core_out_u32(&out,(value)); } while(0)
    VALUE(" id ",appfw_active_id());core_out_str(&out," backend ");core_out_str(&out,backend_name());
    VALUE(" fps_milli ",s_ctx.fps_milli);VALUE(" frames ",s_frames);
    VALUE(" presents ",board_swap_count()-s_app_swaps);VALUE(" errors ",s_errors);
    VALUE(" scene ",s_active && s_active->id==APPFW_R4?r4_current_scene():0u);
    VALUE(" ladder ",s_active && s_active->id==APPFW_R4?r4_current_ladder():0u);
    VALUE(" dropped ",logq_dropped(&s_logq));VALUE(" tick_ms ",p.tick_ms);
    VALUE(" irqA ",board_irq_frame_events());VALUE(" heap ",p.heap_free);
    VALUE(" faults ",board_irq_faults());
    VALUE(" tasks ",p.tasks);VALUE(" idle ",p.idle);VALUE(" monitor ",p.monitor);
    core_out_str(&out,"\r\n");appfw_log(line);
#undef VALUE
}
int appfw_init(uint32_t start_id)
{
    logq_init(&s_logq,s_log_mem,LOGQ_BYTES);
    memset(&s_rt,0,sizeof s_rt);memset(&s_ctx,0,sizeof s_ctx);
    s_active=NULL;s_request=NULL;s_cleanup=NULL;s_frames=s_errors=s_prev=s_blocked=0;s_fault=0;
    board_puts("console boot\r\nconsole protocol 2 tick_hz 1000\r\n");
    if(stg_runtime_boot(&s_rt)!=0)return -1;
    stg_runtime_set_active(&s_rt);
    s_rt.backend=console_platform_hardware()?1:0;
    s_ctx.rt=&s_rt;s_ctx.log=&s_logq;s_ctx.shown=-1;
    stg_modes_set_log(&s_logq);r4_set_log(&s_logq);
    stg_runtime_r4_install_hooks();r4_set_key_source(appfw_input_held);
    if(console_platform_hardware() && stg_runtime_tex_load(&s_rt)!=0)
        board_puts("console capability tex unavailable\r\n");
    if(activate(appfw_app_id(start_id))!=0) {
        s_cleanup=appfw_app_id(start_id);return recover("boot-enter");
    }
    return 0;
}
int appfw_step(uint32_t keys)
{
    const uint32_t pressed=keys&~s_prev;
    const uint32_t launch=keys&BOARD_KEY_LAUNCH_MASK;
    const uint32_t old_launch=s_prev&BOARD_KEY_LAUNCH_MASK;
    const appfw_app *next=NULL;
    int rc=APPFW_FRAME_IDLE;
    s_prev=keys;s_blocked&=keys;
    if(pressed&BOARD_KEY_BACK)next=&g_app_menu;
    else if(launch==BOARD_KEY_LAUNCH_MASK && old_launch!=launch)next=appfw_app_id(APPFW_R4);
    else if(launch!=BOARD_KEY_LAUNCH_MASK) {
        if(pressed&BOARD_KEY_MODE1)next=appfw_app_id(APPFW_DEMO);
        else if(pressed&BOARD_KEY_MODE2)next=appfw_app_id(APPFW_GAME);
        else if(pressed&BOARD_KEY_MODE3)next=appfw_app_id(APPFW_PRESS);
    }
    if(!next)next=s_request;
    if(next)rc=switch_to(next,keys);
    else if(!s_fault && s_active) {
        uint32_t app_keys=keys&~BOARD_KEY_LAUNCH_MASK&~BOARD_KEY_BACK&~s_blocked;
        rc=s_active->frame(&s_ctx,app_keys,s_frames);
        if(rc<0) { s_cleanup=s_active;rc=recover("frame"); }
        else if(rc==APPFW_FRAME_OK)++s_frames;
    }
    status();pump();
    return rc<0?-1:0;
}
int appfw_shutdown(void)
{
    if(s_active) {
        if(s_active->leave(&s_ctx)!=0) { s_cleanup=s_active;error_event("shutdown");s_fault=1; }
        else { complete(s_active);event("leave",s_active); }
    }
    s_active=NULL;
    while(logq_used(&s_logq)) {
        if(!board_tx_room())board_wait_frame();
        pump();board_wait_yield();
    }
    return s_fault || s_errors || logq_dropped(&s_logq)?-1:0;
}
