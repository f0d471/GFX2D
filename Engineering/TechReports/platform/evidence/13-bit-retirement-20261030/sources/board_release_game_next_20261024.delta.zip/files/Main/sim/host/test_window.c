/* Native SDL integration: real desktop fullscreen, letterboxing, texture reset,
   focus release and framebuffer identity. Include the host implementation to
   query its actual SDL texture without adding test APIs to the product. */
#include "../../sw/bsp/host/board.c"
#include <assert.h>
#ifdef _WIN32
#include <SDL_syswm.h>
#endif
#undef assert
#define assert(expression) do { if(!(expression)) { \
    fprintf(stderr,"WINDOW CHECK FAIL line %d: %s\n",__LINE__,#expression); \
    fflush(stderr);exit(1); } } while(0)

static void key(SDL_Scancode code,SDL_Keymod mod)
{
    SDL_Event event;memset(&event,0,sizeof event);
    event.type=SDL_KEYDOWN;event.key.state=SDL_PRESSED;
    event.key.windowID=SDL_GetWindowID(s_win);
    event.key.keysym.scancode=code;event.key.keysym.sym=SDL_GetKeyFromScancode(code);
    event.key.keysym.mod=(Uint16)mod;
    assert(SDL_PushEvent(&event)==1);
    (void)board_keys();SDL_Delay(25);(void)board_keys();
}

static uint32_t pixels(void)
{
    uint32_t value=2166136261u,*fb=board_fb(0);
    for(unsigned y=0;y<FB_HEIGHT;++y)for(unsigned x=0;x<FB_WIDTH;++x)
        value=(value^fb[y*FB_ROW_PIXELS+x])*16777619u;
    return value;
}

int main(void)
{
    board_init();
#ifdef _WIN32
    if(getenv("GFX2D_WINDOW_FOCUS_ONLY"))goto focus_check;
#endif
    for(unsigned y=0;y<FB_HEIGHT;++y)for(unsigned x=0;x<FB_WIDTH;++x)
        board_fb(0)[y*FB_ROW_PIXELS+x]=(x*3u<<16)^y*17u;
    uint32_t original=pixels();
    int width,height;SDL_GetWindowSize(s_win,&width,&height);
    for(unsigned i=0;i<12;++i) {
        printf("WINDOW STEP fullscreen %u\n",i);fflush(stdout);
        key(i&1u?SDL_SCANCODE_RETURN:SDL_SCANCODE_F11,i&1u?KMOD_ALT:KMOD_NONE);
        assert(SDL_GetWindowFlags(s_win)&SDL_WINDOW_FULLSCREEN);
        key(SDL_SCANCODE_ESCAPE,KMOD_NONE);
        assert(!(SDL_GetWindowFlags(s_win)&SDL_WINDOW_FULLSCREEN));
        int w,h;SDL_GetWindowSize(s_win,&w,&h);assert(w==width && h==height);
    }
    puts("WINDOW FULLSCREEN PASS F11/AltEnter/Escape x12 restore");
    for(unsigned scale=1;scale<=3;++scale) {
        key((SDL_Scancode)(SDL_SCANCODE_F1+scale-1),KMOD_NONE);
        int w,h;SDL_GetWindowSize(s_win,&w,&h);
        assert(w==(int)FB_WIDTH*(int)scale && h==(int)FB_HEIGHT*(int)scale);
    }
    SDL_SetWindowSize(s_win,1000,700);SDL_Delay(30);(void)board_keys();
    int logical_w,logical_h;float sx,sy;
    SDL_RenderGetLogicalSize(s_ren,&logical_w,&logical_h);SDL_RenderGetScale(s_ren,&sx,&sy);
    assert(logical_w==(int)FB_WIDTH && logical_h==(int)FB_HEIGHT);
    assert(sx>0 && sy>0 && sx-sy<0.001f && sy-sx<0.001f);
    puts("WINDOW SCALE PASS F1/F2/F3 and 4:3 logical aspect after arbitrary resize");
    SDL_ScaleMode mode;key(SDL_SCANCODE_F4,KMOD_NONE);
    assert(!SDL_GetTextureScaleMode(s_tex,&mode) && mode==SDL_ScaleModeLinear);
    SDL_Event reset;memset(&reset,0,sizeof reset);reset.type=SDL_RENDER_DEVICE_RESET;
    assert(SDL_PushEvent(&reset)==1);(void)board_keys();
    assert(!SDL_GetTextureScaleMode(s_tex,&mode) && mode==SDL_ScaleModeLinear);
    key(SDL_SCANCODE_F4,KMOD_NONE);
    assert(!SDL_GetTextureScaleMode(s_tex,&mode) && mode==SDL_ScaleModeNearest);
    assert(pixels()==original);
    puts("WINDOW FILTER PASS nearest/linear, renderer reset, framebuffer unchanged");
#ifdef _WIN32
focus_check:
    ;
    SDL_SysWMinfo info;SDL_VERSION(&info.version);
    assert(SDL_GetWindowWMInfo(s_win,&info));
    HWND window=info.info.win.window;
    SDL_Window *recipient=SDL_CreateWindow("MYRIAD focus check",100,100,320,240,SDL_WINDOW_HIDDEN);
    assert(recipient);SDL_SysWMinfo other;SDL_VERSION(&other.version);
    assert(SDL_GetWindowWMInfo(recipient,&other));
    SDL_RaiseWindow(s_win);
    DWORD foreground=GetWindowThreadProcessId(GetForegroundWindow(),0),own=GetCurrentThreadId();
    BOOL attached=foreground!=own?AttachThreadInput(own,foreground,TRUE):FALSE;
    ShowWindow(window,SW_RESTORE);SetForegroundWindow(window);SetActiveWindow(window);SetFocus(window);
    if(attached)AttachThreadInput(own,foreground,FALSE);
    SDL_Delay(40);(void)board_keys();
    if(GetForegroundWindow()!=window) {
        fputs("INCOMPLETE Windows did not grant the test window foreground; no key injected\n",stderr);
        return 3;
    }
    INPUT input;memset(&input,0,sizeof input);input.type=INPUT_KEYBOARD;
    input.ki.wScan=(WORD)MapVirtualKeyW('W',MAPVK_VK_TO_VSC);input.ki.dwFlags=KEYEVENTF_SCANCODE;
    assert(SendInput(1,&input,sizeof input)==1);
    uint32_t pressed=0;
    for(unsigned attempt=0;attempt<20 && !(pressed&BOARD_KEY_UP);++attempt) {
        SDL_Delay(10);pressed=board_keys();
    }
    unsigned focus_flags=SDL_GetWindowFlags(s_win);
    int sdl_w=SDL_GetKeyboardState(0)[SDL_SCANCODE_W];
    int native_w=GetAsyncKeyState('W');
    SDL_ShowWindow(recipient);SDL_RaiseWindow(recipient);
    SetForegroundWindow(other.info.win.window);SDL_Delay(25);
    uint32_t released=board_keys();
    /* Always release before checking observations, including failed assertions. */
    input.ki.dwFlags=KEYEVENTF_SCANCODE|KEYEVENTF_KEYUP;
    assert(SendInput(1,&input,sizeof input)==1);SDL_Delay(20);(void)board_keys();
    printf("WINDOW KEY DIAG flags=%u SDL_W=%d native_W=%d pressed=%u released=%u\n",
        focus_flags,sdl_w,native_w,pressed,released);fflush(stdout);
    assert(pressed&BOARD_KEY_UP);assert(released==0);
    SDL_DestroyWindow(recipient);
    puts("WINDOW FOCUS PASS own-window W press and focus-loss release");
#endif
    memset(&reset,0,sizeof reset);reset.type=SDL_QUIT;
    assert(SDL_PushEvent(&reset)==1);(void)board_keys();assert(board_should_quit());
    puts("WINDOW EXIT PASS");SDL_Quit();return 0;
}
