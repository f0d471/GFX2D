/******************************************************************************
* @file r4_scene.c: 固定 30Hz 的世界逻辑与真实三维几何
* @brief 世界/自机/弹幕共享 R1 投影、setup 与 z；相机固定，自机独立横移。
*        墙面按世界深度分段，近缘延伸至视口外；整个物体发射或显式失败。
******************************************************************************/
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "board.h"
#include "r4.h"
#include "r4_scene.h"
#include "core/xorshift32.h"

#define CAM_STEP (4 * R4_ONE / R4_TICK_HZ)
#define MOVE_STEP (2 * R4_ONE / R4_TICK_HZ)
#define E_STEP (5 * R4_ONE / R4_TICK_HZ)
#define P_STEP (16 * R4_ONE / R4_TICK_HZ)
#define DRAW_FAR (36 * R4_ONE)
#ifndef R4_DISABLE_WALL_CACHE
#define R4_DISABLE_WALL_CACHE 0
#endif

uint32_t r4_gate_x_of(uint32_t seq, uint32_t rng0)
{
    static const int32_t pos[3] = {-R4_ONE, 0, R4_ONE};
    return (uint32_t)pos[(seq + rng0) % 3u];
}

void r4_world_init(r4_world *w, uint32_t seed)
{
    xs32 g;
    for (unsigned i=0;i<sizeof(*w);++i) ((uint8_t *)w)[i]=0;
    xs32_seed(&g,seed);w->rng=xs32_next(&g)%3u;
    w->shield=R4_SHIELD_INIT;w->bombs=2;w->ship_y=-3*R4_ONE/4;w->ladder=2;
    w->enemy=(r4_bullet){0,R4_ONE/5,-10*R4_ONE,1};w->enemy_hp=3;
    for (unsigned i=0;i<R4_GATE_SLOTS;++i) {
        w->gate[i].dist=R4_GATE_FIRST+i*R4_GATE_SPACING;
        w->gate[i].x=r4_gate_x_of(i,w->rng);
    }
    w->gate_seq=R4_GATE_SLOTS;
}

static void enemy_fire(r4_world *w,int32_t x,int32_t y,int32_t z,int spread)
{
    for(int k=-spread;k<=spread;++k) {
        for(unsigned i=0;i<R4_EBULLET_MAX;++i) if(!w->ebul[i].alive) {
            int32_t ticks=(-z-(int32_t)w->d-R4_SHIP_Z)/(CAM_STEP+E_STEP);
            if(ticks<1)ticks=1;
            w->ebul[i]=(r4_bullet){x,y,z,1};
            w->e_vx[i]=(w->cam_x-x+k*R4_ONE/2)/ticks;
            w->e_vy[i]=(w->ship_y-y+k*R4_ONE/5)/ticks;
            break;
        }
    }
}

static void hurt(r4_world *w)
{
    if(w->invulnerable || !w->shield)return;
    --w->shield;w->invulnerable=35;
    if(!w->shield)w->respawn=60;
}

void r4_world_tick(r4_world *w,uint32_t keys,uint32_t *fail)
{
    int32_t dir=((keys&BOARD_KEY_RIGHT)!=0)-((keys&BOARD_KEY_LEFT)!=0);
    int32_t vertical=((keys&BOARD_KEY_UP)!=0)-((keys&BOARD_KEY_DOWN)!=0);
    (void)fail;
    ++w->ticks;
    if(keys&(BOARD_KEY_UP|BOARD_KEY_DOWN|BOARD_KEY_LEFT|BOARD_KEY_RIGHT))w->manual=1;
    if(!w->manual) {
        int32_t x=fx_sin((uint16_t)(w->ticks*180u))*2;
        dir=x>w->cam_x?1:x<w->cam_x?-1:0;
        w->cam_x=x;
        w->ship_y=-3*R4_ONE/4+fx_sin((uint16_t)(w->ticks*340u))/3;
    } else {
        w->cam_x+=dir*MOVE_STEP;
        w->ship_y+=vertical*MOVE_STEP;
    }
    if(w->cam_x>R4_ONE)w->cam_x=R4_ONE;
    if(w->cam_x< -R4_ONE)w->cam_x= -R4_ONE;
    if(w->ship_y>0)w->ship_y=0;
    if(w->ship_y< -R4_ONE)w->ship_y= -R4_ONE;
    w->strafe=dir;w->pitch=vertical;
    w->bank+=(dir*20000-w->bank)/4;
    /* Exactly 4m/s at 30Hz. The same world-grid phase repeats every 30 ticks. */
    w->d=(uint32_t)(((uint64_t)w->ticks*4u*R4_ONE)/R4_TICK_HZ);
    if(w->invulnerable)--w->invulnerable;
    if(w->enemy_hit)--w->enemy_hit;
    if(w->blast_ticks)--w->blast_ticks;
    if(w->respawn && !--w->respawn) {
        w->shield=R4_SHIELD_INIT;w->invulnerable=60;
        w->score=w->score>500?w->score-500:0;
    }
    if((keys&BOARD_KEY_BOMB) && !(w->last_keys&BOARD_KEY_BOMB) && w->bombs) {
        --w->bombs;w->invulnerable=60;
        for(unsigned i=0;i<R4_EBULLET_MAX;++i)w->ebul[i].alive=0;
        w->blast=(r4_bullet){w->cam_x,w->ship_y,-(int32_t)w->d-4*R4_ONE,1};
        w->blast_ticks=20;
    }
    w->last_keys=keys;
    if(w->pcooldown)--w->pcooldown;
    if(!w->pcooldown && w->shield) {
        for(unsigned i=0;i<R4_PBULLET_MAX;++i)if(!w->pbul[i].alive) {
            w->pbul[i]=(r4_bullet){w->cam_x,w->ship_y+R4_ONE/30,
                -(int32_t)w->d-R4_SHIP_Z-R4_ONE/5,1};break;
        }
        w->pcooldown=3;
    }
    for(unsigned i=0;i<R4_GATE_SLOTS;++i) {
        r4_gate *g=w->gate+i;
        if(!g->dist)continue;
        if(!g->fired && g->dist>w->d+5u*R4_ONE && g->dist<w->d+15u*R4_ONE) {
            g->fired=1;
            enemy_fire(w,(int32_t)g->x,R4_ONE/2,-(int32_t)g->dist,1);
        }
        /* The ship crosses the gate before the camera does. */
        if(!g->passed && w->d+R4_SHIP_Z>=g->dist) {
            int32_t dx=w->cam_x-(int32_t)g->x;
            g->passed=1;
            if(dx>R4_GATE_OPEN-R4_SHIP_HALF || dx< -R4_GATE_OPEN+R4_SHIP_HALF ||
               w->ship_y< -R4_HALF_H+R4_SHIP_HALF)hurt(w);
            else w->score+=50;
        }
        if(g->dist<w->d) {
            g->dist=R4_GATE_FIRST+w->gate_seq*R4_GATE_SPACING;
            g->x=r4_gate_x_of(w->gate_seq++,w->rng);g->passed=0;g->fired=0;
        }
    }
    if(w->ladder<2)w->enemy.alive=0;
    else if(w->enemy.alive) {
        w->enemy.x=fx_sin((uint16_t)(w->ticks*370u))*2;
        w->enemy.y=R4_ONE/5+fx_sin((uint16_t)(w->ticks*240u))/2;
        if(w->ticks%24u==0u)enemy_fire(w,w->enemy.x,w->enemy.y,w->enemy.z,0);
        if(w->enemy.z+(int32_t)w->d>= -R4_SHIP_Z)w->enemy.alive=0;
    } else if(w->ticks%45u==0u) {
        w->enemy=(r4_bullet){0,R4_ONE/5,-(int32_t)w->d-18*R4_ONE,1};w->enemy_hp=3;
    }
    for(unsigned i=0;i<R4_EBULLET_MAX;++i) {
        r4_bullet *b=w->ebul+i;
        if(!b->alive)continue;
        b->x+=w->e_vx[i];b->y+=w->e_vy[i];b->z+=E_STEP;
        if(b->z+(int32_t)w->d>= -R4_SHIP_Z) {
            int32_t dx=b->x-w->cam_x,dy=b->y-w->ship_y;
            b->alive=0;
            if(dx<R4_GRAZE_DIST && dx> -R4_GRAZE_DIST && dy<R4_GRAZE_DIST && dy> -R4_GRAZE_DIST) {
                if(dx<R4_HIT_DIST && dx> -R4_HIT_DIST && dy<R4_HIT_DIST && dy> -R4_HIT_DIST)hurt(w);
                else {++w->graze;w->score+=10;}
            }
        }
    }
    for(unsigned i=0;i<R4_PBULLET_MAX;++i) {
        r4_bullet *b=w->pbul+i;
        int32_t old=b->z;
        if(!b->alive)continue;
        b->z-=P_STEP;
        if(b->z+(int32_t)w->d< -DRAW_FAR)b->alive=0;
        if(w->enemy.alive && old>=w->enemy.z && b->z<=w->enemy.z) {
            int32_t dx=b->x-w->enemy.x,dy=b->y-w->enemy.y;
            if(dx<R4_ONE/2 && dx> -R4_ONE/2 && dy<R4_ONE/2 && dy> -R4_ONE/2) {
                b->alive=0;w->enemy_hit=5;
                if(w->enemy_hp && !--w->enemy_hp) {
                    w->enemy.alive=0;w->score+=100;
                    w->blast=w->enemy;w->blast_ticks=15;
                }
            }
        }
    }
    if(w->score>w->hiscore)w->hiscore=w->score;
}

static int emit_failed;
typedef struct {
    rast_record records[64];
    rast_setup_stats stats;
    int32_t phase;
    uint32_t count;
    uint8_t valid;
} wall_cache_entry;
static wall_cache_entry wall_cache[30];
static fx16_mat4 wall_projection;
static rast_viewport wall_viewport;
static uint32_t wall_ladder;
static void vertex(rast_view_vertex *v,int32_t x,int32_t y,int32_t z,
                   uint16_t u,uint16_t t,uint32_t color)
{
    *v=(rast_view_vertex){x,y,z,u,t,color};
}
static uint32_t polygon(const rast_view_vertex *v,unsigned n,const rast_viewport *vp,
                        uint32_t flags,const fx16_mat4 *p,rast_record *out,
                        uint32_t cap,rast_setup_stats *st)
{
    int r=rast_setup_view_vp(v,n,p,R4_NEAR_Z,R4_FAR_Z,vp,flags,out,cap,st);
    if(r<0)emit_failed=1;
    return r>0?(uint32_t)r:0;
}
static uint32_t facing(int32_t x,int32_t y,int32_t z,int32_t hw,int32_t hh,
                       uint32_t c,unsigned u,unsigned t,uint32_t flags,
                       const rast_viewport *vp,const fx16_mat4 *p,
                       rast_record *out,uint32_t cap,rast_setup_stats *st)
{
    rast_view_vertex v[4];
    vertex(v,x-hw,y+hh,z,u,t,c);vertex(v+1,x+hw,y+hh,z,u+496,t,c);
    vertex(v+2,x+hw,y-hh,z,u+496,t+496,c);vertex(v+3,x-hw,y-hh,z,u,t+496,c);
    return polygon(v,4,vp,flags,p,out,cap,st);
}

static uint32_t wall(unsigned face,int32_t near_z,int32_t far_z,uint32_t color,
                     const rast_viewport *vp,const fx16_mat4 *p,unsigned flags,
                     rast_record *out,uint32_t cap,rast_setup_stats *st)
{
    rast_view_vertex v[4];
    const int32_t corners[4][2]={{-R4_HALF_W,R4_HALF_H},{-R4_HALF_W,-R4_HALF_H},
                              {R4_HALF_W,-R4_HALF_H},{R4_HALF_W,R4_HALF_H}};
    unsigned a=face,b=(face+1)%4;
    vertex(v,corners[a][0],corners[a][1],near_z,0,0,color);
    vertex(v+1,corners[a][0],corners[a][1],far_z,0,496,color);
    vertex(v+2,corners[b][0],corners[b][1],far_z,496,496,color);
    vertex(v+3,corners[b][0],corners[b][1],near_z,496,0,color);
    return polygon(v,4,vp,flags,p,out,cap,st);
}

uint32_t r4_world_emit(const r4_world *w,const fx16_mat4 *projection,
                       const rast_viewport *vp,uint32_t ladder,
                       rast_record *out,uint32_t cap,rast_setup_stats *counts)
{
    rast_setup_stats st={0};
    uint32_t n=0,flat=RAST_VCOLOR_EN;
    uint32_t walls=flat|(ladder>=2?RAST_TEX_EN:0);
    uint32_t keyed=ladder>=2?(RAST_TEX_EN|RAST_KEY_EN|RAST_VCOLOR_EN):flat;
    int32_t phase=(int32_t)(w->d%R4_SEG_LEN);
    const int32_t planes[5]={R4_NEAR_PAD,6*R4_ONE-phase,10*R4_ONE-phase,
                            18*R4_ONE-phase,34*R4_ONE-phase};
    const uint32_t fog[4]={0xffffffff,0xffb0c4e0,0xff607898,0xff283c58};
    emit_failed=0;
    if(!w || !projection || !vp || !out || cap<256)return UINT32_MAX;
    if(wall_ladder!=ladder || memcmp(&wall_projection,projection,sizeof *projection) ||
       memcmp(&wall_viewport,vp,sizeof *vp)) {
        for(unsigned i=0;i<30;++i)wall_cache[i].valid=0;
        wall_ladder=ladder;wall_projection=*projection;wall_viewport=*vp;
    }
    wall_cache_entry *entry=wall_cache+w->ticks%30u;
    if(!R4_DISABLE_WALL_CACHE && entry->valid && entry->phase==phase) {
        n=entry->count;memcpy(out,entry->records,n*sizeof *out);st=entry->stats;
    } else {
        for(unsigned band=0;band<4;++band)for(unsigned face=0;face<4;++face) {
            uint32_t c=ladder>=2?fog[band]:(band==0?0xff253d60u:band==1?0xff1b304cu:
                                          band==2?0xff142139u:0xff0c1428u);
            if(face==1)c=(c&0xff000000u)|((c>>16&255u)<<16)|((c>>8&255u)*3u/5u<<8)|(c&255u);
            n+=wall(face,-planes[band],-planes[band+1],c,vp,projection,walls,out+n,cap-n,&st);
        }
        if(!emit_failed && n<=64) {
            memcpy(entry->records,out,n*sizeof *out);entry->count=n;entry->phase=phase;
            entry->stats=st;entry->valid=1;
        }
    }
    /* All visible gates participate in z, including gates behind enemies/bullets. */
    for(unsigned i=0;i<R4_GATE_SLOTS;++i) {
        const r4_gate *g=w->gate+i;
        int32_t z=(int32_t)w->d-(int32_t)g->dist;
        int32_t o=R4_GATE_OPEN,t=R4_GATE_THICK,x=(int32_t)g->x;
        int32_t h=R4_HALF_H*4/5;
        uint32_t c=((g->dist/R4_GATE_SPACING)%3u==0)?0xffff6088u:0xff60ffb8u;
        if(!g->dist || z> -R4_SHIP_Z-R4_ONE/3 || z< -DRAW_FAR)continue;
        n+=facing(x-o,0,z,t,h,c,512,0,walls,vp,projection,out+n,cap-n,&st);
        n+=facing(x+o,0,z,t,h,c,512,0,walls,vp,projection,out+n,cap-n,&st);
        n+=facing(x,h,z,o,t,c,512,0,walls,vp,projection,out+n,cap-n,&st);
        n+=facing(x,-h,z,o,t,c,512,0,walls,vp,projection,out+n,cap-n,&st);
    }
    if(ladder>=2 && w->enemy.alive) {
        uint32_t c=w->enemy_hit?0xffffffffu:0xffffd890u;
        n+=facing(w->enemy.x,w->enemy.y,(int32_t)w->d+w->enemy.z,
            R4_ONE/2,R4_ONE/2,c,0,512,keyed,vp,projection,out+n,cap-n,&st);
    }
    /* Six solid faces, cockpit, and a two-color flame share the same 3-axis pose. */
    if(w->shield) {
        const int32_t local[9][3]={{0,1300,-13100},{-13100,-430,4370},{13100,-430,4370},
            {-3932,-3932,10922},{3932,-3932,10922},{0,3932,9830},
            {-1800,-900,10922},{1800,-900,10922},{0,-3500,23000}};
        const unsigned faces[8][3]={{0,5,1},{0,2,5},{0,4,3},{1,5,3},{2,4,5},{3,5,4},{6,7,8},{0,3,4}};
        const uint32_t colors[8]={0xff287ca0,0xff36a6cc,0xff74ddf8,0xff185878,
            0xff206e92,0xff104460,0xff52bfff,0xff4094b8};
        rast_view_vertex v[9];
        int32_t roll=w->bank;
        int32_t cosine=FX16_ONE-fx16_mul(roll,roll)/2;
        for(unsigned i=0;i<9;++i) {
            int32_t x=fx16_mul(local[i][0],cosine)-fx16_mul(local[i][1],roll);
            int32_t y=fx16_mul(local[i][0],roll)+fx16_mul(local[i][1],cosine);
            int32_t z=local[i][2]+w->pitch*local[i][1]/5+w->strafe*local[i][0]/6;
            if(i==8)z+=(int32_t)(w->ticks%4u)*600;
            vertex(v+i,x+w->cam_x,y+w->ship_y,z-R4_SHIP_Z,0,0,0);
        }
        for(unsigned i=0;i<8;++i) {
            rast_view_vertex tri[3];uint32_t c=colors[i];
            if(w->invulnerable && (w->ticks&4u))c=0xffe0f8ff;
            for(unsigned j=0;j<3;++j){tri[j]=v[faces[i][j]];tri[j].color=c;}
            /* Some faces can reverse under banking; retain both sides. */
            uint32_t before=n;
            n+=polygon(tri,3,vp,flat,projection,out+n,cap-n,&st);
            if(n==before){rast_view_vertex tmp=tri[1];tri[1]=tri[2];tri[2]=tmp;
                n+=polygon(tri,3,vp,flat,projection,out+n,cap-n,&st);}
        }
    }
    for(unsigned i=0;i<R4_PBULLET_MAX;++i) {
        const r4_bullet *b=w->pbul+i;
        if(!b->alive)continue;
        n+=facing(b->x,b->y,(int32_t)w->d+b->z,R4_ONE/40,R4_ONE/9,
            0xffa0ffe0,0,0,flat,vp,projection,out+n,cap-n,&st);
    }
    for(unsigned i=0;i<R4_EBULLET_MAX;++i) {
        const r4_bullet *b=w->ebul+i;
        if(!b->alive)continue;
        n+=facing(b->x,b->y,(int32_t)w->d+b->z,R4_BULLET_HALF,R4_BULLET_HALF,
            0xffffffff,512,512,keyed,vp,projection,out+n,cap-n,&st);
    }
    if(w->blast_ticks)for(unsigned i=0;i<3;++i) {
        int32_t radius=(20-(int32_t)w->blast_ticks)*R4_ONE/24;
        int32_t x=w->blast.x+(i==0?-radius:i==1?radius:0);
        int32_t y=w->blast.y+(i==2?radius:0);
        n+=facing(x,y,(int32_t)w->d+w->blast.z,R4_ONE/12,R4_ONE/12,
            0xffffd070,0,0,flat,vp,projection,out+n,cap-n,&st);
    }
    if(counts){counts->backface+=st.backface;counts->sliver+=st.sliver;
        counts->clipped+=st.clipped;counts->emitted+=st.emitted;}
    return emit_failed?UINT32_MAX:n;
}

int r4_world_prewarm(const fx16_mat4 *projection,const rast_viewport *vp,
                     uint32_t ladder,rast_record *scratch,uint32_t cap)
{
    r4_world w;r4_world_init(&w,R4_SEED);
    for(unsigned i=0;i<30;++i) {
        w.ticks=i;w.d=(uint32_t)(((uint64_t)i*4u*R4_ONE)/R4_TICK_HZ);
        if(r4_world_emit(&w,projection,vp,ladder,scratch,cap,NULL)==UINT32_MAX)return -1;
    }
    return 0;
}
